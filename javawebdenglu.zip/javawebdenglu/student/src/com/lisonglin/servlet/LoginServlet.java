package com.lisonglin.servlet;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.lisonglin.dao.Student;
import com.lisonglin.service.StudentService;

public class LoginServlet implements Servlet {
	
	@Override
	public void destroy() {

	}

	@Override
	public ServletConfig getServletConfig() {
		return null;
	}

	@Override
	public String getServletInfo() {
		return null;
	}

	@Override
	public void init(ServletConfig config) throws ServletException {

	}

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		System.out.println("send servlet service");
		//提交的数据有可能有中文， 怎么处理。
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		//1. 获取客户端提交的信息
		String userName = request.getParameter("username");
		String password = request.getParameter("pwd");
		StudentService ss=new StudentService();
		System.out.println("username:"+userName+",pwd:"+password);
		Student user=new Student();
		user.setUserName(userName);
		user.setPwd(password);
		if(ss.valiUser(user)) {
			response.getWriter().write("欢迎你！"+user.getUserName());
		}else {
			response.getWriter().write("用户名或者密码错误！");
		}
	}

}
