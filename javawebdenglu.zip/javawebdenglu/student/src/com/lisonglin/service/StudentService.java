package com.lisonglin.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.lisonglin.dao.Student;
import com.lisonglin.util.Conn;

public class StudentService {
	private Connection con = null;
	private PreparedStatement pst = null;
	
	public StudentService() {
		con =Conn.getConnection();
	}
	
	//编写登录验证方法valiUser()
	public boolean valiUser(Student user){
		try{
			pst = con.prepareStatement("select * from user where username=? and pwd=?");
			pst.setString(1, user.getUserName());
			pst.setString(2, user.getPwd());
			ResultSet rs =pst.executeQuery();
			if(rs.next()){
				return true;
			}else{
				return false;
			}
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
}
