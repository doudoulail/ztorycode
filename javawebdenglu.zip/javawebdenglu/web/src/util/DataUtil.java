package util;

import java.sql.Connection;
import java.sql.DriverManager;
public class DataUtil {
	
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = 	DriverManager.getConnection("jdbc:mysql://localhost:3306/user?usecode=true&characterEncoding=utf-8","root","123");//三个参数：数据库地址，用户名，密码
			System.out.print(con.getMetaData().getURL());
			return con;	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
}
