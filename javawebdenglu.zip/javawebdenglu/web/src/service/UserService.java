package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import entity.User;
import util.DataUtil;

public class UserService {
	private Connection con = null;
	private PreparedStatement pst = null;
	
	public UserService() {
		con = DataUtil.getConnection();
	}
	
	//编写登录验证方法valiUser()
	public boolean valiUser(User user){
		try{
			pst = con.prepareStatement("select * from user where username=? and pwd=?");
			pst.setString(1, user.getUsername());
			pst.setString(2, user.getPwd());
			ResultSet rs =pst.executeQuery();
			if(rs.next()){
				return true;
			}else{
				return false;
			}
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
}
