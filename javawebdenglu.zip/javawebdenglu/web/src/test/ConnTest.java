package test;

import util.DataUtil;

public class ConnTest {
	public static void main(String[] args) {
			System.out.println(DataUtil.getConnection());
	}

}
