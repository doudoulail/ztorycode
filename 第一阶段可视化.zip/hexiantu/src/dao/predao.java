package dao;

import java.sql.*;
import java.util.ArrayList;

import entity.Pre;
import util.DBUtil;

public class predao {
    public ArrayList<Pre> getquanguo()
    {
        ArrayList<Pre> list=new ArrayList<>();
        String sql="select * from info";
        Connection con=null;
        Statement state=null;
        ResultSet rs=null;
        con=DBUtil.getConn();
        Pre bean=null;
        int flag=0;
        try {
            state=con.createStatement();
            rs=state.executeQuery(sql);
            while(rs.next())
            {
                String name=rs.getString("Province");
                String confirmed=rs.getString("Confirmed_num");
                bean=new Pre(name,confirmed);
                list.add(bean);
                if(name.equals("西藏自治区")){
                    flag=1;
                }
                if(flag==1)
                    break;
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        DBUtil.close(rs, state, con);
        return list;
    }
    public ArrayList<Pre> findtime(String btime,String etime)
    {
        String begin="";
        String []s=btime.split("-");
        for(int i=0;i<s.length;i++)
            begin+=s[i].toString();
        
        String end="";
        String []e=etime.split("-");
        for(int i=0;i<e.length;i++)
            end+=e[i].toString();
        System.out.println(begin+" "+end);
        int bg=Integer.valueOf(begin);
        int ed=Integer.valueOf(end);
        //System.out.println(bg+" "+end);
        ArrayList<Pre> list=new ArrayList<>();
        String sql="select * from info";
        Connection con=null;
        Statement state=null;
        ResultSet rs=null;
        con=DBUtil.getConn();
        Pre bean=null;
        try {
            state=con.createStatement();
            rs=state.executeQuery(sql);
            while(rs.next())
            {
                int id=rs.getInt("id");
                String name=rs.getString("Province");
                String city=rs.getString("city");
                String confirmed=rs.getString("Confirmed_num");
                String cured=rs.getString("Cured_num");
                String dead=rs.getString("Dead_num");
                String date=rs.getString("Date");
                String ans="";
                String date2=date.substring(0, 10);
                String []d=date2.split("-");
                for(int i=0;i<d.length;i++)
                {
                    ans+=d[i].toString();
                }
                int k=Integer.valueOf(ans);
                System.out.println(k);
                if(k>=bg&&k<=ed) {
                    bean=new Pre(id,name,city,confirmed,cured,dead,date);
                    list.add(bean);
                }
            }
        } catch (SQLException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        DBUtil.close(rs, state, con);
        return list;
    }
}
