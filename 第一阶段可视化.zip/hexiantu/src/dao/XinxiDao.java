package dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import entity.Pre;
import util.DBUtil;
public class XinxiDao {
 
 /*
  * 将函数设置为Boolean类型，只返回真值或假值给service层，方便
  */
 
 public boolean rename(String name) {
  //搜索数据库表course，检查是否重名
  String sql = "select * from admin where name ='" + name + "'";
        Connection conn =DBUtil.conn() ;
        Statement st= null;
        ResultSet rs = null;
        boolean bean=false;
        try {
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()) {
             bean = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(rs,st, conn);
        }
        return bean;
 }
 

	 
	 
	 public Pre getCoursebyName(String name) {
	   String sql = "select * from courses where name ='" + name + "'";
	         Connection conn =DBUtil.conn() ;
	         Statement st= null;
	         ResultSet rs = null;
	         Pre course=null;
	         try {
	             st = conn.createStatement();
	             rs = st.executeQuery(sql);
	             while (rs.next()) {
	                 String teacher = rs.getString("teacher");
	                 String classroom = rs.getString("classroom");
	                 course = new Pre(0, name, teacher, classroom, classroom, classroom, classroom);
	             }
	         } catch (Exception e) {
	             e.printStackTrace();
	         } finally {
	             DBUtil.close(rs,st, conn);
	         }
	         return course;
	 }
	 public List<Pre> select(String name, String teacher, String classroom) {
	  String sql = "select * from info where ";
	   if (name !=null) {
	    sql += "name like '%" + name + "%'";
	   }
	   else if (teacher !=null) {
	             sql += "teacher like '%" + teacher + "%'";
	         }
	   else if (classroom !=null) {
	             sql += "classroom like '%" + classroom + "%'";
	         }
	         List<Pre> list = new ArrayList<>();
	         Connection conn =DBUtil.conn() ;
	         Statement st= null;
	         ResultSet rs = null;
	         try {
	             st = conn.createStatement();
	             rs = st.executeQuery(sql);
	             Pre course=null;
	             while (rs.next()) {
	                 String name2 = rs.getString("name");
	                 String teacher2 = rs.getString("teacher");
	                 String classroom2 = rs.getString("classroom");
	                 course= new Pre(0, name2, teacher2, classroom2, classroom2, classroom2, classroom2);
	                 list.add(course);
	             }
	         } catch (Exception e) {
	             e.printStackTrace();
	         } finally {
	             DBUtil.close(rs,st, conn);
	         }
	         return list;
	 }
	 public List<Pre> list() {
	  String sql = "select * from courses";
	  List<Pre> list = new ArrayList<>();
	        Connection conn =DBUtil.conn() ;
	        Statement st= null;
	        ResultSet rs = null;
	        try {
	            st = conn.createStatement();
	            rs = st.executeQuery(sql);
	            Pre course=null;
	            while (rs.next()) {
	                String name2 = rs.getString("name");
	                String teacher2 = rs.getString("teacher");
	                String classroom2 = rs.getString("classroom");
	                course= new Pre(0, name2, teacher2, classroom2, classroom2, classroom2, classroom2);
	                list.add(course);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            DBUtil.close(rs,st, conn);
	        }
	        return list;
	 }
	}