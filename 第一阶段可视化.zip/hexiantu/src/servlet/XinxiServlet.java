package servlet;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import entity.Pre;
import service.XinxiService;
/**
 * Servlet implementation class courseServlet
 */
@WebServlet("/courseServlet")
public class XinxiServlet extends HttpServlet{
    private static final long serialVersionUID = 1L;
    XinxiService service=new XinxiService();

    private void select(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
     //查找
        req.setCharacterEncoding("utf-8");
        String name = req.getParameter("name");
        String teacher = req.getParameter("teacher");
        String classroom = req.getParameter("classroom");
        List<Pre> course = service.select(name, teacher, classroom);
        req.setAttribute("info", course);
        req.getRequestDispatcher("keshihuaceshi.jsp").forward(req,resp);
 
    }
}