package entity;

public class Pre {
    private int id;
    private String name;
    private String city;
    private String confirmed;
    private String cured;
    private String dead;
    private String date;
    
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getConfirmed() {
        return confirmed;
    }
    public void setConfirmed(String confirmed) {
        this.confirmed = confirmed;
    }
    public String getCured() {
        return cured;
    }
    public void setCured(String cured) {
        this.cured = cured;
    }
    public String getDead() {
        return dead;
    }
    public void setDead(String dead) {
        this.dead = dead;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    
    public Pre() {
        super();
    }
    public Pre(int id, String name, String city, String confirmed, String cured, String dead, String date) {
        super();
        this.id = id;
        this.name = name;
        this.city = city;
        this.confirmed = confirmed;
        this.cured = cured;
        this.dead = dead;
        this.date = date;
    }
    public Pre(String name,String confirmed) {
        super();
        this.name = name;
        this.confirmed = confirmed;

    }
    
}