package service;
import java.util.List;
import dao.XinxiDao;
import entity.Pre;
public class XinxiService{
    XinxiDao dao=new XinxiDao();
 
    public List<Pre> list() {
     //列出表中所有信息
        return dao.list();
    }

	public List<Pre> select(String name, String teacher, String classroom) {
		// TODO Auto-generated method stub
		return null;
	}
}
