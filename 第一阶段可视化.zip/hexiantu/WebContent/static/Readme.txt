
myValidate.js为表单验证规则，可在里面添加rules，用的时候直接把其作为js文件连接进jsp页面就行了
md5.js 为post之前对信息加密，调用方法
